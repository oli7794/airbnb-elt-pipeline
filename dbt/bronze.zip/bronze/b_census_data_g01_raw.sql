{{ config(
    materialized = 'table',
    schema = 'bronze',
    alias='b_census_data_g01_raw'
) }}

SELECT *
FROM {{ source('raw', 'census_data_g01_raw') }}