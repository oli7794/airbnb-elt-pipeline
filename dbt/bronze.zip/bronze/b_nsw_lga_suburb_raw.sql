{{ config(
    materialized = 'table',
    schema = 'bronze',
    alias='lga_suburb'
) }}

SELECT *
FROM {{ source('raw', 'nsw_lga_suburb_raw') }}