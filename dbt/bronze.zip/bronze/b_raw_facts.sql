{{ config(
    materialized = 'table',
    schema = 'bronze',
    alias='facts'
) }}

SELECT *
FROM {{ source('raw', 'raw_facts') }}