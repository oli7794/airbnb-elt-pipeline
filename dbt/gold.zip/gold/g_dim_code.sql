{{
    config(
        materialized='table',  
        unique_key='lga_code',
        alias='lga_code'
    )
}}

WITH source AS (
    SELECT * FROM {{ ref('s_lga_code') }})  

,renamed AS (
    SELECT
        CAST(LGA_CODE AS TEXT) AS lga_code,  
        TRIM(LGA_NAME) AS lga_name
    FROM source
)

SELECT * FROM renamed