{{
    config(
        unique_key='host_id',
        alias='g_dim_host'
    )
}}

WITH facts_snapshot AS (
    SELECT
        host_id,
        host_name,
        host_neighbourhood,
        dbt_valid_from::timestamp AS valid_from,  
        dbt_valid_to::timestamp as valid_to   
    FROM {{ ref('facts_snapshot') }}
),

unknown AS (
    SELECT
        'unknown' AS host_id,
        'unknown' AS host_name,
        'unknown' AS host_neighbourhood,
        '1900-01-01'::timestamp  AS valid_from,
        NULL::timestamp AS valid_to
)

SELECT * FROM unknown
UNION ALL
SELECT * FROM facts_snapshot