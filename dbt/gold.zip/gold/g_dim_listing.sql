{{ config(unique_key="listing_id", alias="g_dim_listing") }}

with
    snapshot_data as (
        select
            listing_id,
            listing_neighbourhood,
            property_type,
            room_type,
            dbt_valid_from::timestamp AS valid_from,  
            dbt_valid_to::timestamp as valid_to   
        from {{ ref("facts_snapshot") }}
    ),

    unknown as (
        select
            'unknown' as listing_id,
            'unknown' as listing_neighbourhood,
            'unknown' as property_type,
            'unknown' as room_type,
            '1900-01-01'::timestamp as valid_from,
            null::timestamp as valid_to
    )

-- Ensure all the columns match across the SELECT statements
select *
from unknown
union all
select *
from snapshot_data