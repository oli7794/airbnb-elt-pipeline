{{
    config(
        unique_key='suburb_name',
        alias='g_dim_suburb'
    )
}}

WITH source AS (
    SELECT * 
    FROM {{ ref('s_lga_suburb') }} 
),

cleaned AS (
    SELECT DISTINCT
        suburb_name,
        lga_name
    FROM source
),

unknown AS (
    SELECT
        'unknown' AS suburb_name,
        'unknown' AS lga_name
)

SELECT * FROM unknown
UNION ALL
SELECT * FROM cleaned