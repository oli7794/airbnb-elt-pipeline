{{ config(materialized="view", alias="dm_host_neighbourhood") }}
with
    latest_scraped_month as (
        select date_trunc('month', max(f.scraped_date)) as max_scraped_month
        from {{ ref("g_fact_listings") }} as f
    )
select
    s.suburb_name as suburb_name,
    a.lga_code as lga_code,  
    to_char(date_trunc('month', f.host_since), 'YYYY-MM') as month_year,
    count(distinct h.host_id) as distinct_hosts,
    sum(
        case when f.has_availability = true then (30 - f.availability_30) * f.price end
    ) as estimated_revenue,
    g02.median_rent_weekly as median_rent_weekly,
    (
        sum(
            case
                when f.has_availability = true then (30 - f.availability_30) * f.price
            end
        )::float
        / nullif(count(distinct h.host_id), 0)
    ) as estimated_revenue_per_host
from {{ ref("g_fact_listings") }} as f
join {{ ref("g_dim_host") }} as h on f.host_id = h.host_id
join {{ ref("g_dim_suburb") }} as s on h.host_neighbourhood = s.suburb_name
join {{ ref("g_dim_code") }} as a on s.lga_name = a.lga_name
join {{ ref("g_dim_census_g01") }} as g01 on g01.lga_code = a.lga_code 
join {{ ref("g_dim_census_g02") }} as g02 on g02.lga_code = a.lga_code
join
    latest_scraped_month as lm
    on date_trunc('month', f.scraped_date) = lm.max_scraped_month
where f.has_availability = true
group by
    s.suburb_name, g02.median_rent_weekly, a.lga_code, date_trunc('month', f.host_since)
order by
    s.suburb_name, g02.median_rent_weekly, a.lga_code, date_trunc('month', f.host_since)