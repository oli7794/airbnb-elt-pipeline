
{{
    config(
        materialized='view',
        alias='dm_listing_neighbourhood'
    )
}}

SELECT 
    listing_neighbourhood,
    month_year,
    active_listing_rate,
    min_price,
    max_price,
    median_price,
    avg_price,
    distinct_hosts,
    superhost_rate,
    avg_review_scores_rating,
    total_stays,
    avg_estimated_revenue,
    CASE 
        WHEN LAG(active_listing_rate) OVER (PARTITION BY listing_neighbourhood ORDER BY month_year) = 0 THEN NULL
        ELSE ((active_listing_rate - LAG(active_listing_rate) OVER (PARTITION BY listing_neighbourhood ORDER BY month_year)) / 
            LAG(active_listing_rate) OVER (PARTITION BY listing_neighbourhood ORDER BY month_year)) * 100
    END AS active_listing_pct_change,
    CASE 
        WHEN LAG(100 - active_listing_rate) OVER (PARTITION BY listing_neighbourhood ORDER BY month_year) = 0 THEN NULL
        ELSE ((100 - active_listing_rate) - LAG(100 - active_listing_rate) OVER (PARTITION BY listing_neighbourhood ORDER BY month_year)) / 
            LAG(100 - active_listing_rate) OVER (PARTITION BY listing_neighbourhood ORDER BY month_year) * 100
    END AS inactive_listing_pct_change
FROM (
    SELECT
        listing_neighbourhood,
        month_year,
        active_listings,
        (active_listings::FLOAT / total_listings::FLOAT) * 100 AS active_listing_rate,
        min_price,
        max_price,
        median_price,
        avg_price,
        distinct_hosts,
        CASE 
            WHEN distinct_hosts = 0 THEN 0
            ELSE (superhosts::FLOAT / distinct_hosts::FLOAT) * 100
        END AS superhost_rate,
        avg_review_scores_rating,
        total_stays,
        CASE 
            WHEN active_listings = 0 THEN 0
            ELSE (total_estimated_revenue::FLOAT / active_listings::FLOAT)
        END AS avg_estimated_revenue
    FROM (
        SELECT
            b.listing_neighbourhood,
            TO_CHAR(DATE_TRUNC('month', f.host_since), 'YYYY-MM') AS month_year,
            COUNT(*) AS total_listings,
            COUNT(CASE WHEN f.has_availability = TRUE THEN 1 END) AS active_listings,
            COUNT(DISTINCT f.host_id) AS distinct_hosts,
            COUNT(DISTINCT CASE WHEN f.host_is_superhost = TRUE THEN f.host_id END) AS superhosts,
            MIN(f.price) AS min_price,
            MAX(f.price) AS max_price,
            PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY f.price) AS median_price,
            round(AVG(f.price),2) AS avg_price,
            AVG(CASE WHEN f.has_availability = TRUE and f.review_scores_rating != 'NaN' THEN f.review_scores_rating END) AS avg_review_scores_rating,
            SUM(CASE WHEN f.has_availability = TRUE THEN 30 - f.availability_30 END) AS total_stays,
            SUM(CASE WHEN f.has_availability = TRUE THEN (30 - f.availability_30) * f.price END) AS total_estimated_revenue
        FROM {{ ref('g_fact_listings') }} AS f
        JOIN {{ ref('g_dim_listing') }} AS b
            ON f.listing_id = b.listing_id
        JOIN {{ ref('g_dim_host') }} AS h
            ON f.host_id = h.host_id
            AND f.scraped_date::timestamp >= '2021-04-15'::timestamp
        GROUP BY b.listing_neighbourhood, DATE_TRUNC('month', f.host_since)
    ) AS active_listings_data
) AS metrics_data
ORDER BY listing_neighbourhood, month_year