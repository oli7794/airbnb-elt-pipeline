{{ config(materialized="view", alias="g_dm_property_type") }}


WITH latest_scraped_month AS (
    SELECT
        DATE_TRUNC('month', MAX(f.scraped_date)) AS max_scraped_month
    FROM {{ ref('g_fact_listings') }} AS f
)

SELECT 
    property_type,
    room_type,
    accommodates,
    month_year,
    active_listing_rate,
    min_price,
    max_price,
    median_price,
    avg_price,
    distinct_hosts,
    superhost_rate,
    avg_review_scores_rating,
    total_stays,
    avg_estimated_revenue,
    case
        when
            lag(active_listing_rate) over (
                partition by property_type, room_type, accommodates order by month_year
            )
            = 0
        then null
        else
            (
                (
                    active_listing_rate - lag(active_listing_rate) over (
                        partition by property_type, room_type, accommodates
                        order by month_year
                    )
                ) / lag(active_listing_rate) over (
                    partition by property_type, room_type, accommodates
                    order by month_year
                )
            )
            * 100
    end as active_listing_pct_change,
    case
        when
            lag(100 - active_listing_rate) over (
                partition by property_type, room_type, accommodates order by month_year
            )
            = 0
        then null
        else
            (
                (100 - active_listing_rate) - lag(100 - active_listing_rate) over (
                    partition by property_type, room_type, accommodates
                    order by month_year
                )
            ) / lag(100 - active_listing_rate) over (
                partition by property_type, room_type, accommodates order by month_year
            )
            * 100
    end as inactive_listing_pct_change
FROM
    (
        SELECT
            property_type,
            room_type,
            accommodates,
            month_year,
            active_listings,
            CASE 
                WHEN total_listings = 0 THEN 0
                ELSE (active_listings::float / total_listings::float) * 100
            END AS active_listing_rate,
            min_price,
            max_price,
            median_price,
            avg_price,
            distinct_hosts,
            CASE 
                WHEN distinct_hosts = 0 THEN 0
                ELSE (superhosts::float / distinct_hosts::float) * 100
            END AS superhost_rate,
            avg_review_scores_rating,
            total_stays,
            CASE 
                WHEN active_listings = 0 THEN 0
                ELSE (total_estimated_revenue::float / active_listings::float)
            END AS avg_estimated_revenue
        FROM
            (
                SELECT
                    l.property_type,
                    l.room_type,
                    f.accommodates,
                    TO_CHAR(DATE_TRUNC('month', f.host_since), 'YYYY-MM') AS month_year,
                    COUNT(*) AS total_listings,
                    COUNT(CASE WHEN f.has_availability = TRUE THEN 1 END) AS active_listings,
                    COUNT(DISTINCT f.host_id) AS distinct_hosts,
                    COUNT(DISTINCT CASE WHEN f.host_is_superhost = TRUE THEN f.host_id END) AS superhosts,
                    MIN(f.price) AS min_price,
                    MAX(f.price) AS max_price,
                    PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY f.price) AS median_price,
                    ROUND(AVG(f.price), 2) AS avg_price,
                    AVG(CASE WHEN f.has_availability = TRUE AND f.review_scores_rating != 'NaN' THEN f.review_scores_rating END) AS avg_review_scores_rating,
                    SUM(CASE WHEN f.has_availability = TRUE THEN 30 - f.availability_30 END) AS total_stays,
                    SUM(CASE WHEN f.has_availability = TRUE THEN (30 - f.availability_30) * f.price END) AS total_estimated_revenue
                FROM {{ ref("g_fact_listings") }} AS f
                JOIN {{ ref("g_dim_listing") }} AS l 
                    ON f.listing_id = l.listing_id
                JOIN {{ ref("g_dim_host") }} AS h 
                    ON f.host_id = h.host_id
                    AND f.scraped_date::timestamp >= '2021-04-15'::timestamp
                JOIN latest_scraped_month AS lm
                    ON DATE_TRUNC('month', f.scraped_date) = lm.max_scraped_month
                GROUP BY l.property_type, l.room_type, f.accommodates, month_year
            ) AS active_listings_data
    ) AS metrics_data
ORDER BY property_type, room_type, accommodates, month_year
