{{
    config(
        materialized = 'table',
        alias='g_fact_listings'
    )
}}

WITH fact_data AS (
    SELECT
        listing_id,
        host_id,
        price,
        accommodates,
        availability_30,
        review_scores_rating,
        review_scores_value,
        host_since,
        has_availability,
        host_is_superhost,
        scraped_date
    FROM {{ ref('s_facts') }}  
),

unknown AS (
    SELECT
        'unknown' AS listing_id,
        'unknown' AS host_id,
        0 AS price,
        0 AS accommodates,
        0 AS availability_30,
        0 AS review_scores_rating,
        0 AS review_scores_value,
        '1900-01-01'::timestamp  as host_since,
        NULL::boolean AS has_availability,
        NULL::boolean AS host_is_superhost,
        '1900-01-01'::timestamp  as scraped_date
),

cleaned AS (
    SELECT * FROM fact_data
)

SELECT * FROM unknown
UNION ALL
SELECT * FROM cleaned