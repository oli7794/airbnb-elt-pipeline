{% snapshot facts_snapshot %}

{{
    config(
        unique_key='listing_id',
        strategy='timestamp',
        updated_at='scraped_date',
        alias='facts_snapshot'
    )
}}

WITH source AS (
    SELECT * 
    FROM {{ ref('b_raw_facts') }}  -- Reference to the raw facts table
),

renamed AS (
    SELECT
        CAST(HOST_ID AS TEXT) AS host_id,
        LISTING_ID,
        TRIM(HOST_NAME) AS host_name,
        TRIM(LOWER(host_neighbourhood)) AS host_neighbourhood,
        TRIM(LISTING_NEIGHBOURHOOD) AS listing_neighbourhood,
        TRIM(PROPERTY_TYPE) AS property_type,
        TRIM(ROOM_TYPE) AS room_type,
        scraped_date     
    FROM source
)

SELECT * FROM renamed


{% endsnapshot %}