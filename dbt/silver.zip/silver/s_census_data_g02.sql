{{
    config(
        unique_key='lga_code_2016',
        alias='s_census_data_g02'
    )
}}

WITH source AS (
    SELECT * FROM {{ ref('b_census_data_g02_raw') }}
),

renamed AS (
    SELECT
        TRIM(REPLACE(LGA_CODE_2016, 'LGA', '')) as lga_code,
        CAST(MEDIAN_AGE_PERSONS AS BIGINT) AS median_age_persons,
        CAST(MEDIAN_MORTGAGE_REPAY_MONTHLY AS BIGINT) AS median_mortgage_repay_monthly,
        CAST(MEDIAN_TOT_PRSNL_INC_WEEKLY AS BIGINT) AS median_tot_prsnl_inc_weekly,
        CAST(MEDIAN_RENT_WEEKLY AS BIGINT) AS median_rent_weekly,
        CAST(MEDIAN_TOT_FAM_INC_WEEKLY AS BIGINT) AS median_tot_fam_inc_weekly,
        CAST(AVERAGE_NUM_PSNS_PER_BEDROOM AS FLOAT) AS average_num_psns_per_bedroom,
        CAST(MEDIAN_TOT_HHD_INC_WEEKLY AS BIGINT) AS median_tot_hhd_inc_weekly,
        CAST(AVERAGE_HOUSEHOLD_SIZE AS FLOAT) AS average_household_size
    FROM source
)

SELECT * FROM renamed
