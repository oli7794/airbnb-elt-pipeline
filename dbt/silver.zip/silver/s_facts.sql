{{ config(
    unique_key='listing_id',
    alias='s_facts'  
) }}

WITH source AS (
    SELECT * 
    FROM {{ ref('b_raw_facts') }}  -- Reference to the raw facts table
),

renamed AS (
    SELECT
        CAST(LISTING_ID AS TEXT) AS listing_id,
        scraped_date::timestamp,
        CAST(HOST_ID AS TEXT) AS host_id,  
        CAST(SCRAPE_ID AS TEXT) AS scrape_id,
        CAST(ACCOMMODATES AS INT) AS accommodates,
        CAST(PRICE AS DECIMAL) AS price,
        CASE WHEN HOST_IS_SUPERHOST = 't' THEN TRUE ELSE FALSE END AS host_is_superhost,
        CASE WHEN HAS_AVAILABILITY = 't' THEN TRUE ELSE FALSE END AS has_availability,
        CAST(AVAILABILITY_30 AS INT) AS availability_30,
        CAST(NUMBER_OF_REVIEWS AS INT) AS number_of_reviews,
        CAST(REVIEW_SCORES_RATING AS DECIMAL) AS review_scores_rating,
        CAST(REVIEW_SCORES_ACCURACY AS DECIMAL) AS review_scores_accuracy,
        CAST(REVIEW_SCORES_CLEANLINESS AS DECIMAL) AS review_scores_cleanliness,
        CAST(REVIEW_SCORES_CHECKIN AS DECIMAL) AS review_scores_checkin,
        CAST(REVIEW_SCORES_COMMUNICATION AS DECIMAL) AS review_scores_communication,
        CAST(REVIEW_SCORES_VALUE AS DECIMAL) AS review_scores_value,
         CASE WHEN TRIM(HOST_SINCE) = '' THEN NULL 
                 WHEN HOST_SINCE ~ '^[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}$' THEN TO_DATE(HOST_SINCE, 'DD/MM/YYYY') 
                 ELSE NULL END AS host_since             
    FROM source
)
    
SELECT * FROM renamed
