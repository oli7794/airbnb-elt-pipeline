{{
    config(
        unique_key='lga_code',
        alias='s_lga_code'
    )
}}

WITH source AS (
    SELECT * FROM {{ ref('b_nsw_lga_code_raw') }}
),

cleaned AS (
    SELECT
        LGA_CODE,
        LGA_NAME
    FROM source
),

renamed AS (
    SELECT
        CAST(LGA_CODE AS TEXT) AS lga_code,
        TRIM(LOWER(lga_name)) AS lga_name  
    FROM cleaned
)

SELECT * FROM renamed
