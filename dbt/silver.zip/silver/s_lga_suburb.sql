{{
    config(
        unique_key='lga_name',
        alias='s_lga_suburb'
    )
}}

WITH source AS (
    SELECT * FROM {{ ref('b_nsw_lga_suburb_raw') }}
),

cleaned AS (
    SELECT
        TRIM(LOWER(lga_name)) as lga_name,
        TRIM(LOWER(suburb_name)) as suburb_name
    FROM source
),

renamed AS (
    SELECT
        TRIM(LGA_NAME) AS lga_name,       
        TRIM(SUBURB_NAME) AS suburb_name  
    FROM cleaned
)

SELECT * FROM renamed
